

<!DOCTYPE html> 
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="fr"> <![endif]--> 
<!--[if IE 7]> <html class="no-js ie7 oldie" lang="fr"> <![endif]--> 
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="fr"> <![endif]--> 
<!--[if gt IE 8]> <html class="no-js" lang="fr"> <![endif]--> 
<html lang="pt"> 
<head> 
	<meta charset="utf-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="robots" content="index, follow" />  
	<title>Sua tiragem está sendo interpretada...</title> 
	<meta name="description" content="Por favor, aguarde... Sua tiragem está sendo interpretada. Você poderá consultar as interpretações das cartas do Tarot Oraculo.">

	<!-- Mobile Metas --> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="theme-color" content="#000"/>

	<!-- Favicons --> 
	<link rel="shortcut icon" type="image/png" href="https://www.otarot.net/images/favicon.png"> 
	<link rel="apple-touch-icon" href="https://www.otarot.net/images/icons/apple-touch-icon.png"> 
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.otarot.net/images/icons/apple-touch-icon-72x72.png"> 
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.otarot.net/images/icons/apple-touch-icon-114x114.png"> 
	<link rel="manifest" href="https://www.otarot.net/js/manifest.json">

	<!-- Fonts --> 
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://www.otarot.net/css/bootstrap.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/css/animate.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/style.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/global.css" /> 

	<!--[if lt IE 9]> 
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script> 
		<script src="https://oss.maxcdn.com/libs/respond.scripts/1.4.2/respond.min.js"></script> 
	<![endif]--> 
<script>
    document.createElement( "picture" );
  </script>
<script src="https://www.otarot.net/js/picturefill.min.js" async></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1516487466373126"
     crossorigin="anonymous"></script>

<script type="text/javascript">
(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;

(_axcb = window._axcb || []).push(function(sdk) {
  sdk.on('cookies:complete', function(choices) {
    if (!choices['Google Ads']) {   
        window.adsbygoogle.requestNonPersonalizedAds = 1;
    }
    window.adsbygoogle.pauseAdRequests = 0;
  });
});
</script>


</head> 

<body> 
<div id="myNav" class="overlay">
  <div class="overlay-content">
  	<div class="menu_contour">
    <a style="border-bottom:1px solid #ddd;margin-bottom:20px;font-size:18px;cursor:mouse;color:#ddd;padding-bottom:8px;">oTarot</a>
    <a href="https://www.otarot.net/" >Tarot online</a>    
    <a href="https://www.otarot.net/tarot-do-amor/" >Tarot do Amor</a>
    <a href="https://www.otarot.net/tarot-sim-nao/" >Tarot Sim Nao</a>
    <a href="https://www.otarot.net/tarot-cigano/" >Baralho Cigano</a>
    <a href="https://www.otarot.net/tarot-oraculo/" class='actif'>Tarot Oraculo</a>
</div>
  </div>
</div>
	<!-- header --> 
	<header> 
		<div class="container"> 
			<div class="row"> 
				<div class="col-xs-6"> 
					<a href="https://www.otarot.net/" class="logo" title="oTarot"> 
						<img src="https://www.otarot.net/images/logo.png" alt="oTarot"> 
						<h1>oTarot.<span>net</span></h1>
					</a>
				</div> 
				
				<div class="col-xs-6"> 
					<div class="right-header align_right"> 
						<div class="inline"> 
							<span onclick="openNav()" class="the_span" id="the_span">&#9776;</span>
						</div> 
					</div> 
				</div> 
			</div> 
		</div> 
	</header> 
	<!-- header --> 
<link rel="stylesheet" href="https://www.otarot.net/tarot-oraculo/style.css" /> 
<link href="https://fonts.googleapis.com/css?family=Playball" rel="stylesheet">

<div class="card-area">
    <div class="container">

            


        <div class="t-pageHeader">
            <h1>Tarot do Oraculo</h1>
            <h2>Sua tiragem está sendo interpretada</h2> 

        </div>

        <form class="send-form" method="POST" action="interpretacao-final.php">
            <input type="hidden" name="card-1" value="">
            <input type="hidden" name="card-2" value="">
            <input type="hidden" name="card-3" value="">
            <input type="hidden" name="card-4" value="">
            <input type="hidden" name="card-5" value="">
            <input type="hidden" name="card-6" value="">
            <input type="hidden" name="card-7" value="">
            <input type="hidden" name="card-8" value="">
            <input type="hidden" name="card-9" value="">
            <input type="hidden" name="card-10" value="">

            <input type="hidden" name="name-card-1" value="">
            <input type="hidden" name="name-card-2" value="">
            <input type="hidden" name="name-card-3" value="">
            <input type="hidden" name="name-card-4" value="">
            <input type="hidden" name="name-card-5" value="">
            <input type="hidden" name="name-card-6" value="">
            <input type="hidden" name="name-card-7" value="">
            <input type="hidden" name="name-card-8" value="">
            <input type="hidden" name="name-card-9" value="">
            <input type="hidden" name="name-card-10" value="">

             <div class="eva-sexe">
<p style="margin-top:25px;margin-bottom:20px;font-size:2rem;text-align:center;">
Você é: </p>
<input type="radio" name="sexe" value="Man" id="Man"><label for="Man">Homem</label>
	<br>
	<input type="radio" name="sexe" value="Woman" id="Woman"><label for="Woman">Mulher</label>
	<br>
</div>
<a href="" class="valid-sex button" style="display:none;">Validar</a>
</form>
    
        </form>



        <div class="before-results">

            <div class="line-content-init">
                <div class="ligne-1"></div>
                <div class="ligne-2"></div>
                <div class="ligne-3"></div>
            </div>

            <div class="number-content">
                <span class="bulle-1">1</span>
                <span class="bulle-2">2</span>
                <span class="bulle-3">3</span>
            </div>

            <div class="card-front-only card-1" data-number="1">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
            <div class="card-front-only card-2" data-number="2">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
            <div class="card-front-only card-3" data-number="3">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
            <div class="card-front-only card-4">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
            <div class="card-front-only card-5">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
            <div class="card-front-only card-6">
                <img src="" alt="/">
                <p class="name"></p>
            </div>
        </div>


      <div class="associations">
           <div class="association-top clearfix">
              <div class="line-content-final">
                  <div class="line-1"></div>
                  <div class="line-2"></div>
                  <div class="line-3"></div>
              </div>
               <div class="association-left">
                   <div><strong>Associação n°1</strong></div>
                   <div>
                       <div class="card-front-only">
                           <img class="grayscale grayscale-off" src="" alt="/">
                           <p class="name"></p>
                       </div>
                       <div class="card-front-only">
                           <img class="grayscale grayscale-off" src="" alt="/">
                           <p class="name"></p>
                       </div>
                   </div>
               </div>
               <div class="association-right">
                   <div><strong>Associação n°2</strong></div>
                   <div>
                       <div class="card-front-only">
                           <img class="grayscale grayscale-off" src="" alt="/">
                           <p class="name"></p>
                       </div>
                       <div class="card-front-only">
                           <img class="grayscale grayscale-off" src="" alt="/">
                           <p class="name"></p>
                       </div>
                   </div>
               </div>
           </div>
            <div class="association-bottom">
                <div><strong>A conexão</strong></div>
                <div>
                    <div class="card-front-only">
                        <img class="grayscale grayscale-off" src="" alt="/">
                        <p class="name"></p>
                    </div>
                </div>
            </div>

            <img src="images/faces.png" class="faceGraphic" alt="/">
        </div>




    </div>
</div>


<script src="https://www.otarot.net/js/vendor/jquery.js"></script> 
<script src="https://www.otarot.net/js/bootstrap.js"></script> 
<script src="https://www.otarot.net/tarot-oraculo/scripts/css3-animate-it.js"></script>

<script>
        
    setTimeout(function() {
        $('.before-results .card-front-only.card-1').animate({opacity: 1}, 500, "linear", function() { });
    },1000)
    setTimeout(function() {
        $('.before-results .card-front-only.card-2').animate({opacity: 1}, 500, "linear", function() { });
    },2000)
    setTimeout(function() {
        $('.before-results .card-front-only.card-3').animate({opacity: 1}, 500, "linear", function() { });
    },3000)
    setTimeout(function() {
        $('.before-results .card-front-only.card-4').animate({opacity: 1}, 500, "linear", function() { });
    },4000)
    setTimeout(function() {
        $('.before-results .card-front-only.card-5').animate({opacity: 1}, 500, "linear", function() { });
    },5000)
    setTimeout(function() {
        $('.before-results .card-front-only.card-6').animate({opacity: 1}, 500, "linear", function() { });
    },6000)


    setTimeout(function() {
        $('.ligne-1').css('opacity', 1);
    },8000)

    setTimeout(function() {
        $('.before-results .card-front-only.card-1, .before-results .card-front-only.card-4').addClass('blink');
        $('.number-content .bulle-1').css('opacity', 1);
    },9000)



    setTimeout(function() {
        $('.ligne-2').css('opacity', 1);
    },12000)

    setTimeout(function() {
        $('.before-results .card-front-only.card-2, .before-results .card-front-only.card-5').addClass('blink');
        $('.number-content .bulle-2').css('opacity', 1);
    },13000)



    setTimeout(function() {
        $('.ligne-3').css('opacity', 1);
    },16000)

    setTimeout(function() {
        $('.before-results .card-front-only.card-3, .before-results .card-front-only.card-6').addClass('blink');
        $('.number-content .bulle-3').css('opacity', 1);
    },17000)

        setTimeout(function() {
        $('.before-results').hide();
    },20000)


/* Formulaire */

        setTimeout(function(){     
          $('h2').html('Tipo:');
          $('.eva-sexe').fadeIn();
          },22000);

        $('input[type=radio][name=sexe]').change(function() {
            $('.eva-sexe').hide();      
            $('h2').html('Sua tiragem está sendo interpretada');    
            launch();
            return false;                
        })

// END formulaire //

/* Step 6 */
   function launch() {
            $('.mentions').hide();                                      
            $('.form-sexe').fadeOut();

           setTimeout(function() {
                  $('.association-left').animate({opacity: 1}, 500, "linear", function() { });
            },1000)
            setTimeout(function() {
                  $('.association-right').animate({opacity: 1}, 500, "linear", function() { });
            },2000)
            setTimeout(function() {
                  $('.association-bottom').animate({opacity: 1}, 500, "linear", function() { });
            },3000)

            setTimeout(function() {
                  $('.line-content-final .line-1').animate({opacity: 1}, 500, "linear", function() { });
            },5000)
            setTimeout(function() {
                  $('.line-content-final .line-2').animate({opacity: 1}, 500, "linear", function() { });
            },6500)
            setTimeout(function() {
                  $('.line-content-final .line-3').animate({opacity: 1}, 500, "linear", function() { });
            },8000)

            setTimeout(function() {
                  $('.faceGraphic ').animate({opacity: 1}, 500, "linear", function() { });
            },10000)

            setTimeout(function() {
                  $('.faceGraphic ').addClass('rotate');
            },12000)

            setTimeout(function() {$('.send-form').submit(); },18000)
      }
</script>


	<!-- footer --> 
	<footer> 
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<nav>
						<ul class="inline">
							<li><span>Copyright 2021</span></li>
							<li><a href="https://www.otarot.net/.php"></a></li>
							<li><a href="https://www.otarot.net/">A respeito de</a></li>
							<li><a href="https://www.otarot.net/">Contato</a></li>
							<li><a href="javascript:openAxeptioCookies()">Cookies</a></li>
						</ul>
					</nav>
				</div>
				<div class="col-sm-4">
					<ul class="inline">
						<li>
							<a href="https://www.evatarot.net" title="Evatarot.net" target="_blank"><img src="https://www.otarot.net/images/flags/us.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>
						<li>
							<a href="https://www.altarocchi.it" title="AlTarocchi.it" target="_blank"><img src="https://www.otarot.net/images/flags/it.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>
						<li>
							<a href="https://www.gotarot.de" title="GoTarot.de" target="_blank"><img src="https://www.otarot.net/images/flags/de.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>							
						<li>
							<a href="https://www.esotarot.es" title="Esotarot.es" target="_blank"><img src="https://www.otarot.net/images/flags/es.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>						
						<li>
							<a href="https://www.otarot.net" title="Otarot.net" target="_blank"><img src="https://www.otarot.net/images/flags/br.jpg" style="width: 25px;margin-top: -2px;"></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer> 

	<div class="subfooter">
		<p>O futuro não acontece apenas. Você tem que se preparar para isso.</p>
	</div>
	<!-- footer --> 

	<div class="mask"></div>

<script>
function openNav() {

	if(document.getElementById("the_span").innerText == "×") {
		document.getElementById("myNav").style.height = "0%";
	    document.getElementById("the_span").innerHTML = "&#9776;"; 
	}

	else {
		if( $(window).width() > 900) { document.getElementById("myNav").style.height = "60%"; }
		else { document.getElementById("myNav").style.height = "100%"; }
		document.getElementById("the_span").innerHTML = "×";
	}
}

$(window).click(function() {
		document.getElementById("myNav").style.height = "0%";
	    document.getElementById("the_span").innerHTML = "&#9776;"; 		
});

$('.overlay').click(function(event){
    event.stopPropagation();
});

$('header').click(function(event){
    event.stopPropagation();
});
</script>


<script>
window.axeptioSettings = {
  clientId: "607342c466d13d734eecc2ff",
  cookiesVersion: "otarot-base",
};
 
(function(d, s) {
  var t = d.getElementsByTagName(s)[0], e = d.createElement(s);
  e.async = true; e.src = "//static.axept.io/sdk.js";
  t.parentNode.insertBefore(e, t);
})(document, "script");
</script>

<script>

	
function launchGA(){
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-106577387-1', 'auto');
    ga('send', 'pageview');
    }

void 0 === window._axcb && (window._axcb = []);
window._axcb.push(function(axeptio) {
 axeptio.on("cookies:complete", function(choices) {
   if(choices.google_analytics) {
     launchGA();
   }
  });
});

</script>

</body> 
</html>