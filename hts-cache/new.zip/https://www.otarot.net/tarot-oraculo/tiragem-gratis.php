

<!DOCTYPE html> 
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="fr"> <![endif]--> 
<!--[if IE 7]> <html class="no-js ie7 oldie" lang="fr"> <![endif]--> 
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="fr"> <![endif]--> 
<!--[if gt IE 8]> <html class="no-js" lang="fr"> <![endif]--> 
<html lang="pt"> 
<head> 
	<meta charset="utf-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="robots" content="index, follow" />  
	<title>Por favor selecione 10 cartas do Tarot Oraculo</title> 
	<meta name="description" content="Tire as cartas do oráculo do Tarot Oraculo escolhendo 10 cartas do baralho abaixo. Consulte a interpretação gratuita da sua tiragem do Tarot Oraculo.">

	<!-- Mobile Metas --> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="theme-color" content="#000"/>

	<!-- Favicons --> 
	<link rel="shortcut icon" type="image/png" href="https://www.otarot.net/images/favicon.png"> 
	<link rel="apple-touch-icon" href="https://www.otarot.net/images/icons/apple-touch-icon.png"> 
	<link rel="apple-touch-icon" sizes="72x72" href="https://www.otarot.net/images/icons/apple-touch-icon-72x72.png"> 
	<link rel="apple-touch-icon" sizes="114x114" href="https://www.otarot.net/images/icons/apple-touch-icon-114x114.png"> 
	<link rel="manifest" href="https://www.otarot.net/js/manifest.json">

	<!-- Fonts --> 
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://www.otarot.net/css/bootstrap.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/css/animate.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/style.css" /> 
	<link rel="stylesheet" href="https://www.otarot.net/global.css" /> 

	<!--[if lt IE 9]> 
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script> 
		<script src="https://oss.maxcdn.com/libs/respond.scripts/1.4.2/respond.min.js"></script> 
	<![endif]--> 
<script>
    document.createElement( "picture" );
  </script>
<script src="https://www.otarot.net/js/picturefill.min.js" async></script>

<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1516487466373126"
     crossorigin="anonymous"></script>

<script type="text/javascript">
(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;

(_axcb = window._axcb || []).push(function(sdk) {
  sdk.on('cookies:complete', function(choices) {
    if (!choices['Google Ads']) {   
        window.adsbygoogle.requestNonPersonalizedAds = 1;
    }
    window.adsbygoogle.pauseAdRequests = 0;
  });
});
</script>


</head> 

<body> 
<div id="myNav" class="overlay">
  <div class="overlay-content">
  	<div class="menu_contour">
    <a style="border-bottom:1px solid #ddd;margin-bottom:20px;font-size:18px;cursor:mouse;color:#ddd;padding-bottom:8px;">oTarot</a>
    <a href="https://www.otarot.net/" >Tarot online</a>    
    <a href="https://www.otarot.net/tarot-do-amor/" >Tarot do Amor</a>
    <a href="https://www.otarot.net/tarot-sim-nao/" >Tarot Sim Nao</a>
    <a href="https://www.otarot.net/tarot-cigano/" >Baralho Cigano</a>
    <a href="https://www.otarot.net/tarot-oraculo/" class='actif'>Tarot Oraculo</a>
</div>
  </div>
</div>
	<!-- header --> 
	<header> 
		<div class="container"> 
			<div class="row"> 
				<div class="col-xs-6"> 
					<a href="https://www.otarot.net/" class="logo" title="oTarot"> 
						<img src="https://www.otarot.net/images/logo.png" alt="oTarot"> 
						<h1>oTarot.<span>net</span></h1>
					</a>
				</div> 
				
				<div class="col-xs-6"> 
					<div class="right-header align_right"> 
						<div class="inline"> 
							<span onclick="openNav()" class="the_span" id="the_span">&#9776;</span>
						</div> 
					</div> 
				</div> 
			</div> 
		</div> 
	</header> 
	<!-- header --> 
<link rel="stylesheet" href="https://www.otarot.net/tarot-oraculo/style.css" /> 
<link href="https://fonts.googleapis.com/css?family=Playball" rel="stylesheet">
<style>
.retourne {
  pointer-events: none !important;
}
</style>

<div class="card-area">
    <div class="container">

        <div class="t-pageHeader">
            <h1>Tarot do Oraculo</h1>
            <h2>Por favor selecione 10 cartas do baralho abaixo :</h2>
        </div>

        <form class="send-form" method="POST" action="3-cartas-futuro.php">
                <input type="hidden" name="card-1" value=""><input type="hidden" name="card-2" value=""><input type="hidden" name="card-3" value=""><input type="hidden" name="card-4" value=""><input type="hidden" name="card-5" value=""><input type="hidden" name="card-6" value=""><input type="hidden" name="card-7" value=""><input type="hidden" name="card-8" value=""><input type="hidden" name="card-9" value=""><input type="hidden" name="card-10" value="">
                <input type="hidden" name="name-card-1" value=""><input type="hidden" name="name-card-2" value=""><input type="hidden" name="name-card-3" value=""><input type="hidden" name="name-card-4" value=""><input type="hidden" name="name-card-5" value=""><input type="hidden" name="name-card-6" value=""><input type="hidden" name="name-card-7" value=""><input type="hidden" name="name-card-8" value=""><input type="hidden" name="name-card-9" value=""><input type="hidden" name="name-card-10" value="">            </form>

        <div class="moveOpenCards"><div class="pseudo-card"></div></div>
        <div class="forEffect"></div>
        <div class="cards-inner card">

            <div class="cards-inner">
                <div class="cards-round-deck">
                    

                    <div id="card1" class="card-block card-1 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card2" class="card-block card-2 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card3" class="card-block card-3 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card4" class="card-block card-4 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card5" class="card-block card-5 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card6" class="card-block card-6 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card7" class="card-block card-7 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card8" class="card-block card-8 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card9" class="card-block card-9 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card10" class="card-block card-10 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card11" class="card-block card-11 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card12" class="card-block card-12 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card13" class="card-block card-13 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card14" class="card-block card-14 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card15" class="card-block card-15 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card16" class="card-block card-16 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card17" class="card-block card-17 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card18" class="card-block card-18 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card19" class="card-block card-19 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card20" class="card-block card-20 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card21" class="card-block card-21 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card22" class="card-block card-22 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card23" class="card-block card-23 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card24" class="card-block card-24 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card25" class="card-block card-25 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card26" class="card-block card-26 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card27" class="card-block card-27 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card28" class="card-block card-28 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card29" class="card-block card-29 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card30" class="card-block card-30 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card31" class="card-block card-31 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card32" class="card-block card-32 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card33" class="card-block card-33 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card34" class="card-block card-34 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card35" class="card-block card-35 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card36" class="card-block card-36 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card37" class="card-block card-37 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card38" class="card-block card-38 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card39" class="card-block card-39 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card40" class="card-block card-40 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card41" class="card-block card-41 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card42" class="card-block card-42 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card43" class="card-block card-43 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card44" class="card-block card-44 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card45" class="card-block card-45 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card46" class="card-block card-46 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card47" class="card-block card-47 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card48" class="card-block card-48 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card49" class="card-block card-49 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card50" class="card-block card-50 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card51" class="card-block card-51 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card52" class="card-block card-52 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div><div id="card53" class="card-block card-53 " data-rank="">
                                    <div class="card-inner">
                                        <div class="card-back"></div>
                                        <div class="card-front">                       
                                        </div>
                                    </div>
                                </div>

                </div>
            </div>

  <div class="hide-card">
    
    <div>
        <a data-name="Acidente"><img src="images/cards/acidente.jpg" alt="Acidente" class="hidden-card"> 
           <p class="nom-carte">Acidente</p>
        </a>
    </div>

    
    <div>
        <a data-name="Amor"><img src="images/cards/amor.jpg" alt="Amor" class="hidden-card"> 
           <p class="nom-carte">Amor</p>
        </a>
    </div>

    
    <div>
        <a data-name="Suporte"><img src="images/cards/suporte.jpg" alt="Suporte" class="hidden-card"> 
           <p class="nom-carte">Suporte</p>
        </a>
    </div>

    
    <div>
        <a data-name="Dinheiro"><img src="images/cards/dinheiro.jpg" alt="Dinheiro" class="hidden-card"> 
           <p class="nom-carte">Dinheiro</p>
        </a>
    </div>

    
    <div>
        <a data-name="Beleza"><img src="images/cards/beleza.jpg" alt="Beleza" class="hidden-card"> 
           <p class="nom-carte">Beleza</p>
        </a>
    </div>

    
    <div>
        <a data-name="Felicidade"><img src="images/cards/felicidade.jpg" alt="Felicidade" class="hidden-card"> 
           <p class="nom-carte">Felicidade</p>
        </a>
    </div>

    
    <div>
        <a data-name="Campo"><img src="images/cards/campo.jpg" alt="Campo" class="hidden-card"> 
           <p class="nom-carte">Campo</p>
        </a>
    </div>

    
    <div>
        <a data-name="Mudança"><img src="images/cards/mudanca.jpg" alt="Mudança" class="hidden-card"> 
           <p class="nom-carte">Mudança</p>
        </a>
    </div>

    
    <div>
        <a data-name="Claustros"><img src="images/cards/claustros.jpg" alt="Claustros" class="hidden-card"> 
           <p class="nom-carte">Claustros</p>
        </a>
    </div>

    
    <div>
        <a data-name="Descoberta"><img src="images/cards/descoberta.jpg" alt="Descoberta" class="hidden-card"> 
           <p class="nom-carte">Descoberta</p>
        </a>
    </div>

    
    <div>
        <a data-name="Partida"><img src="images/cards/partida.jpg" alt="Partida" class="hidden-card"> 
           <p class="nom-carte">Partida</p>
        </a>
    </div>

    
    <div>
        <a data-name="Despotismo"><img src="images/cards/despotismo.jpg" alt="Despotismo" class="hidden-card"> 
           <p class="nom-carte">Despotismo</p>
        </a>
    </div>

    
    <div>
        <a data-name="Elevação"><img src="images/cards/elevacao.jpg" alt="Elevação" class="hidden-card"> 
           <p class="nom-carte">Elevação</p>
        </a>
    </div>

    
    <div>
        <a data-name="Inimigos"><img src="images/cards/inimigos.jpg" alt="Inimigos" class="hidden-card"> 
           <p class="nom-carte">Inimigos</p>
        </a>
    </div>

    
    <div>
        <a data-name="Negócio"><img src="images/cards/negocio.jpg" alt="Negócio" class="hidden-card"> 
           <p class="nom-carte">Negócio</p>
        </a>
    </div>

    
    <div>
        <a data-name="Família"><img src="images/cards/familia.jpg" alt="Família" class="hidden-card"> 
           <p class="nom-carte">Família</p>
        </a>
    </div>

    
    <div>
        <a data-name="Fatalidade"><img src="images/cards/fatalidade.jpg" alt="Fatalidade" class="hidden-card"> 
           <p class="nom-carte">Fatalidade</p>
        </a>
    </div>

    
    <div>
        <a data-name="Fogo"><img src="images/cards/fogo.jpg" alt="Fogo" class="hidden-card"> 
           <p class="nom-carte">Fogo</p>
        </a>
    </div>

    
    <div>
        <a data-name="Herança"><img src="images/cards/heranca.jpg" alt="Herança" class="hidden-card"> 
           <p class="nom-carte">Herança</p>
        </a>
    </div>

    
    <div>
        <a data-name="Honras"><img src="images/cards/honras.jpg" alt="Honras" class="hidden-card"> 
           <p class="nom-carte">Honras</p>
        </a>
    </div>

    
    <div>
        <a data-name="Inconstância"><img src="images/cards/inconstancia.jpg" alt="Inconstância" class="hidden-card"> 
           <p class="nom-carte">Inconstância</p>
        </a>
    </div>

    
    <div>
        <a data-name="Desgraça"><img src="images/cards/desgraca.jpg" alt="Desgraça" class="hidden-card"> 
           <p class="nom-carte">Desgraça</p>
        </a>
    </div>

    
    <div>
        <a data-name="A Carta Azul"><img src="images/cards/a-carta-azul.jpg" alt="A Carta Azul" class="hidden-card"> 
           <p class="nom-carte">A Carta Azul</p>
        </a>
    </div>

    
    <div>
        <a data-name="Destino"><img src="images/cards/destino.jpg" alt="Destino" class="hidden-card"> 
           <p class="nom-carte">Destino</p>
        </a>
    </div>

    
    <div>
        <a data-name="Grace"><img src="images/cards/grace.jpg" alt="Grace" class="hidden-card"> 
           <p class="nom-carte">Grace</p>
        </a>
    </div>

    
    <div>
        <a data-name="Natividade"><img src="images/cards/natividade.jpg" alt="Natividade" class="hidden-card"> 
           <p class="nom-carte">Natividade</p>
        </a>
    </div>

    
    <div>
        <a data-name="Paz"><img src="images/cards/paz.jpg" alt="Paz" class="hidden-card"> 
           <p class="nom-carte">Paz</p>
        </a>
    </div>

    
    <div>
        <a data-name="Sucesso"><img src="images/cards/sucesso.jpg" alt="Sucesso" class="hidden-card"> 
           <p class="nom-carte">Sucesso</p>
        </a>
    </div>

    
    <div>
        <a data-name="Tabela"><img src="images/cards/tabela.jpg" alt="Tabela" class="hidden-card"> 
           <p class="nom-carte">Tabela</p>
        </a>
    </div>

    
    <div>
        <a data-name="Água"><img src="images/cards/agua.jpg" alt="Água" class="hidden-card"> 
           <p class="nom-carte">Água</p>
        </a>
    </div>

    
    <div>
        <a data-name="Sorte"><img src="images/cards/sorte.jpg" alt="Sorte" class="hidden-card"> 
           <p class="nom-carte">Sorte</p>
        </a>
    </div>

    
    <div>
        <a data-name="Penates"><img src="images/cards/penates.jpg" alt="Penates" class="hidden-card"> 
           <p class="nom-carte">Penates</p>
        </a>
    </div>

    
    <div>
        <a data-name="Estrella Mulher"><img src="images/cards/estrella-mulher.jpg" alt="Estrella Mulher" class="hidden-card"> 
           <p class="nom-carte">Estrella Mulher</p>
        </a>
    </div>

    
    <div>
        <a data-name="Estrella Homem"><img src="images/cards/estrella-homem.jpg" alt="Estrella Homem" class="hidden-card"> 
           <p class="nom-carte">Estrella Homem</p>
        </a>
    </div>

    
    <div>
        <a data-name="Inteligência"><img src="images/cards/inteligencia.jpg" alt="Inteligência" class="hidden-card"> 
           <p class="nom-carte">Inteligência</p>
        </a>
    </div>

    
    <div>
        <a data-name="Doença"><img src="images/cards/doenca.jpg" alt="Doença" class="hidden-card"> 
           <p class="nom-carte">Doença</p>
        </a>
    </div>

    
    <div>
        <a data-name="Malícia"><img src="images/cards/malicia.jpg" alt="Malícia" class="hidden-card"> 
           <p class="nom-carte">Malícia</p>
        </a>
    </div>

    
    <div>
        <a data-name="Novo"><img src="images/cards/novo.jpg" alt="Novo" class="hidden-card"> 
           <p class="nom-carte">Novo</p>
        </a>
    </div>

    
    <div>
        <a data-name="Sentimentos"><img src="images/cards/sentimentos.jpg" alt="Sentimentos" class="hidden-card"> 
           <p class="nom-carte">Sentimentos</p>
        </a>
    </div>

    
    <div>
        <a data-name="Amizade"><img src="images/cards/amizade.jpg" alt="Amizade" class="hidden-card"> 
           <p class="nom-carte">Amizade</p>
        </a>
    </div>

    
    <div>
        <a data-name="Prazer"><img src="images/cards/prazer.jpg" alt="Prazer" class="hidden-card"> 
           <p class="nom-carte">Prazer</p>
        </a>
    </div>

    
    <div>
        <a data-name="Conversas"><img src="images/cards/conversas.jpg" alt="Conversas" class="hidden-card"> 
           <p class="nom-carte">Conversas</p>
        </a>
    </div>

    
    <div>
        <a data-name="Presente"><img src="images/cards/presente.jpg" alt="Presente" class="hidden-card"> 
           <p class="nom-carte">Presente</p>
        </a>
    </div>

    
    <div>
        <a data-name="Julgamento"><img src="images/cards/julgamento.jpg" alt="Julgamento" class="hidden-card"> 
           <p class="nom-carte">Julgamento</p>
        </a>
    </div>

    
    <div>
        <a data-name="Famoso"><img src="images/cards/famoso.jpg" alt="Famoso" class="hidden-card"> 
           <p class="nom-carte">Famoso</p>
        </a>
    </div>

    
    <div>
        <a data-name="Atrasar"><img src="images/cards/atrasar.jpg" alt="Atrasar" class="hidden-card"> 
           <p class="nom-carte">Atrasar</p>
        </a>
    </div>

    
    <div>
        <a data-name="Arruinado"><img src="images/cards/arruinado.jpg" alt="Arruinado" class="hidden-card"> 
           <p class="nom-carte">Arruinado</p>
        </a>
    </div>

    
    <div>
        <a data-name="Sabedoria"><img src="images/cards/sabedoria.jpg" alt="Sabedoria" class="hidden-card"> 
           <p class="nom-carte">Sabedoria</p>
        </a>
    </div>

    
    <div>
        <a data-name="Esterilidade"><img src="images/cards/esterilidade.jpg" alt="Esterilidade" class="hidden-card"> 
           <p class="nom-carte">Esterilidade</p>
        </a>
    </div>

    
    <div>
        <a data-name="Tráfego"><img src="images/cards/trafego.jpg" alt="Tráfego" class="hidden-card"> 
           <p class="nom-carte">Tráfego</p>
        </a>
    </div>

    
    <div>
        <a data-name="Traição"><img src="images/cards/traicao.jpg" alt="Traição" class="hidden-card"> 
           <p class="nom-carte">Traição</p>
        </a>
    </div>

    
    <div>
        <a data-name="União"><img src="images/cards/uniao.jpg" alt="União" class="hidden-card"> 
           <p class="nom-carte">União</p>
        </a>
    </div>

    
    <div>
        <a data-name="Roubando"><img src="images/cards/robando.jpg" alt="Roubando" class="hidden-card"> 
           <p class="nom-carte">Roubando</p>
        </a>
    </div>

    </div>


    </div>
</div>


<script src="https://www.otarot.net/js/vendor/jquery.js"></script> 
<script src="https://www.otarot.net/js/bootstrap.js"></script> 
<script src="https://www.otarot.net/tarot-oraculo/scripts/css3-animate-it.js"></script>
<script src="https://www.otarot.net/tarot-oraculo/scripts/newApp.js"></script>
<script src="https://www.otarot.net/tarot-oraculo/scripts/script-belline.js"></script>

	<!-- footer --> 
	<footer> 
		<div class="container">
			<div class="row">
				<div class="col-sm-8">
					<nav>
						<ul class="inline">
							<li><span>Copyright 2021</span></li>
							<li><a href="https://www.otarot.net/.php"></a></li>
							<li><a href="https://www.otarot.net/">A respeito de</a></li>
							<li><a href="https://www.otarot.net/">Contato</a></li>
							<li><a href="javascript:openAxeptioCookies()">Cookies</a></li>
						</ul>
					</nav>
				</div>
				<div class="col-sm-4">
					<ul class="inline">
						<li>
							<a href="https://www.evatarot.net" title="Evatarot.net" target="_blank"><img src="https://www.otarot.net/images/flags/us.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>
						<li>
							<a href="https://www.altarocchi.it" title="AlTarocchi.it" target="_blank"><img src="https://www.otarot.net/images/flags/it.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>
						<li>
							<a href="https://www.gotarot.de" title="GoTarot.de" target="_blank"><img src="https://www.otarot.net/images/flags/de.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>							
						<li>
							<a href="https://www.esotarot.es" title="Esotarot.es" target="_blank"><img src="https://www.otarot.net/images/flags/es.jpg" style="width: 25px;margin-top: -8px;"></a>
						</li>						
						<li>
							<a href="https://www.otarot.net" title="Otarot.net" target="_blank"><img src="https://www.otarot.net/images/flags/br.jpg" style="width: 25px;margin-top: -2px;"></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</footer> 

	<div class="subfooter">
		<p>O futuro não acontece apenas. Você tem que se preparar para isso.</p>
	</div>
	<!-- footer --> 

	<div class="mask"></div>

<script>
function openNav() {

	if(document.getElementById("the_span").innerText == "×") {
		document.getElementById("myNav").style.height = "0%";
	    document.getElementById("the_span").innerHTML = "&#9776;"; 
	}

	else {
		if( $(window).width() > 900) { document.getElementById("myNav").style.height = "60%"; }
		else { document.getElementById("myNav").style.height = "100%"; }
		document.getElementById("the_span").innerHTML = "×";
	}
}

$(window).click(function() {
		document.getElementById("myNav").style.height = "0%";
	    document.getElementById("the_span").innerHTML = "&#9776;"; 		
});

$('.overlay').click(function(event){
    event.stopPropagation();
});

$('header').click(function(event){
    event.stopPropagation();
});
</script>


<script>
window.axeptioSettings = {
  clientId: "607342c466d13d734eecc2ff",
  cookiesVersion: "otarot-base",
};
 
(function(d, s) {
  var t = d.getElementsByTagName(s)[0], e = d.createElement(s);
  e.async = true; e.src = "//static.axept.io/sdk.js";
  t.parentNode.insertBefore(e, t);
})(document, "script");
</script>

<script>

	
function launchGA(){
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-106577387-1', 'auto');
    ga('send', 'pageview');
    }

void 0 === window._axcb && (window._axcb = []);
window._axcb.push(function(axeptio) {
 axeptio.on("cookies:complete", function(choices) {
   if(choices.google_analytics) {
     launchGA();
   }
  });
});

</script>

</body> 
</html>